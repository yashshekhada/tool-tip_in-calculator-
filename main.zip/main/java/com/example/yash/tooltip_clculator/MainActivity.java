package com.example.yash.tooltip_clculator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageView img;
    GridView gv;
    Context context;
    private static LayoutInflater inflater2 = null;

    ArrayList prgmName;
    public static String [] number={"205 ","265","625","806","300","9000e","600e","202"};
    public static String [] pc={"200 PC ","300 PC","300 PC","300 PC","300 PC","300 PC","300 PC","200 PC"};
    public static int [] prgmImages={R.drawable.chair,R.drawable.chair,R.drawable.chair,R.drawable.chair,R.drawable.chair,R.drawable.chair,R.drawable.chair,R.drawable.chair};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionbar=getSupportActionBar();
        actionbar.hide();

        gv = (GridView) findViewById(R.id.gridView1);

        gv.setAdapter(new ImageAdapter(this, number, pc, prgmImages));





    }



}
