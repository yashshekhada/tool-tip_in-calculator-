package com.example.yash.tooltip_clculator;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.spyhunter99.supertooltips.ToolTip;
import com.spyhunter99.supertooltips.ToolTipManager;
import com.tooltip.Tooltip;

import io.github.douglasjunior.androidSimpleTooltip.SimpleTooltip;

/**
 * Created by yash on 8/5/17.
 */
public class ImageAdapter extends BaseAdapter {


        String[] numbert;
    String[] pct;
        Context context,context2;
        int[] imageId;
        private static LayoutInflater inflater = null;

        public ImageAdapter(MainActivity mainActivity, String[] number,String[] pc, int[] prgmImages) {
            // TODO Auto-generated constructor stub
            numbert=number;
            pct= pc;
            context = mainActivity;
            imageId = prgmImages;
            inflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return numbert.length;
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public class Holder {
            TextView tv;
            TextView tv2;
            ImageView img;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            Holder holder = new Holder();
            final View rowView;
            Context ctx;

            ctx=parent.getContext();


            rowView = inflater.inflate(R.layout.sample_gridlayout, null);
            holder.tv = (TextView) rowView.findViewById(R.id.textView1);
            holder.tv.setTypeface( Validate.setTypeface( ctx ) );
            holder.tv2 = (TextView) rowView.findViewById(R.id.textView2);
            holder.tv2.setTypeface( Validate.setTypeface( ctx ) );
            holder.img = (ImageView) rowView.findViewById(R.id.imageView1);

            holder.tv.setText(numbert[position]);
            holder.tv2.setText(pct[position]);
            holder.img.setImageResource(imageId[position]);

            rowView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                   // Toast.makeText(context, "You Clicked " + numbert[position], Toast.LENGTH_LONG).show();

                    TextView Email;




                   final SimpleTooltip tooltip =new SimpleTooltip.Builder(context)

                                .anchorView(v)

                                .highlightShape(55)
                                .backgroundColor(Color.WHITE)
                                .highlightShape(45)

                                .gravity(Gravity.CENTER)
                                .arrowDrawable(R.drawable.tooltip_arrow)
                                .contentView(R.layout.activity_tooltips)
                                .onDismissListener(new SimpleTooltip.OnDismissListener() {
                                    @Override
                                    public void onDismiss(SimpleTooltip tooltip) {
                                        System.out.println("dismiss " + tooltip);

                                    }
                                })
                                .onShowListener(new SimpleTooltip.OnShowListener() {
                                    @Override
                                    public void onShow(SimpleTooltip tooltip) {


                                    }
                                })
                                    .dismissOnInsideTouch( false )

                                .build();

                    final EditText ed = tooltip.findViewById(R.id.yash);
                    tooltip.findViewById( R.id.t7 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText(ed.getText()+"7" );
                        }
                    } );
                    tooltip.findViewById( R.id.t0 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText(ed.getText()+ "0" );
                        }
                    } );
                    tooltip.findViewById( R.id.t1 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"1" );
                        }
                    } );
                    tooltip.findViewById( R.id.t2 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"2" );
                        }
                    } );
                    tooltip.findViewById( R.id.t3 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"3" );
                        }
                    } );
                    tooltip.findViewById( R.id.t4 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"4" );
                        }
                    } );
                    tooltip.findViewById( R.id.t5 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"5" );
                        }
                    } );
                    tooltip.findViewById( R.id.t6 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"6" );
                        }
                    } );
                    tooltip.findViewById( R.id.t8 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"8" );
                        }
                    } );
                    tooltip.findViewById( R.id.t9 ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( ed.getText()+"9" );
                        }
                    } );
                    tooltip.findViewById( R.id.C ).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ed.setText( "" );
                        }
                    } );
                    tooltip.findViewById( R.id.confirm).setOnClickListener( new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            tooltip.dismiss();
                            Toast.makeText( context, ed.getText(), Toast.LENGTH_SHORT ).show();
                        }
                    } );


                    tooltip.show();





                   /* ToolTip toolTip = new ToolTip()
                            .withText("A demo for tooltips on list view items")
                            .withColor(Color.RED) //or whatever you want
                            .withAnimationType(ToolTip.AnimationType.FROM_MASTER_VIEW)
                            .withShadow();*/


                }
            });

            return rowView;
        }
    }


