package com.example.yash.tooltip_clculator;

import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;

/**
 * Created by Administrator on 5/10/2017.
 */

public class Validate extends Application{


        public static Typeface setTypeface(Context ctx) {
            Typeface font = Typeface.createFromAsset(
                    ctx.getAssets(),
                    "fonts/Helvetica.ttf");
            return font;
        }
    }


